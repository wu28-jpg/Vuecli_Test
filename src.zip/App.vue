<template>
	<div id="app">
		<el-container>
			<el-header></el-header>
			<el-aside>
				<el-menu id="navMenu" :router="true" unique-opened>
					<el-submenu index="1">
						<template slot="title">库存管理</template>
						<el-menu-item-group>
							<el-menu-item><router-link to="/About">about</router-link></el-menu-item>
							<el-menu-item><router-link to="/Home">home</router-link></el-menu-item>
						</el-menu-item-group>
					</el-submenu>
					<el-submenu index="2">
						<template slot="title">采购管理</template>
						<el-menu-item-group>
							<el-menu-item><router-link to="/About">about</router-link></el-menu-item>
							<el-menu-item><router-link to="/Home">home</router-link></el-menu-item>
						</el-menu-item-group>
					</el-submenu>				
				</el-menu>
			</el-aside>
			<el-main id="main">
				<router-view></router-view>
			</el-main>
			<el-footer></el-footer>
		</el-container>

	</div>
</template>
<script>
	// import About from './components/About.vue'
	// import Home from './components/Home.vue'
	// import gonggao from './components/gonggao.vue'
	export default {
		name: 'app',
		// components: {
		// 	About,
		// 	Home,
		// 	gonggao,
		// },
		methods: {
			handleOpen(key, keyPath) {
				console.log(key, keyPath);
			},
			handleClose(key, keyPath) {
				console.log(key, keyPath);
			}
		}
	}
</script>

<style>
	#navMenu {
	}

	#main {
		width: 84%;
	}
</style>
