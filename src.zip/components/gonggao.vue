<template>
	<h2>公告区</h2>
</template>

<script>
</script>
	export default{
		name:'gonggao'
	}
<style>
</style>