<template>
	<h2>你好about</h2>
</template>

<script>
	export default{
		name:'About'
	}
</script>

<style>
</style>