<template>
		<h2>你好home</h2>
</template>

<script>
	export default{
		name:'Home'
	}
</script>

<style>
</style>